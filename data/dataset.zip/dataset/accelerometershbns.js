var Acceleration = require('ripple/platform/phonegap/1.0.0/Acceleration'),
    utils = require('ripple/utils'),
    event = require('ripple/event'),
    _accelerometerInfo = new Acceleration(),
    _watches = {},
    self;

module.exports = self = {
    getCurrentAcceleration: function (onSuccess, onError) {
        // TODO: implement error call if accelerometer is not available, to be driven by behaviours?

        if (typeof onSuccess === "function") {
            setTimeout(function () {
                // TODO: build facility to trigger onError() from emulator
                // see pivotal item: https://www.pivotaltracker.com/story/show/7040343
                onSuccess(utils.copy(_accelerometerInfo));
            }, 1);
        }

    },

    watchAcceleration: function (accelerometerSuccess, accelerometerError, accelerometerOptions) {
        var watchId = (new Date()).getTime().toString(),
            watchObj = {};


        if (accelerometerOptions &&
                accelerometerOptions.frequency && typeof
                accelerometerOptions.frequency === "number" &&
                accelerometerOptions.frequency === Math.floor(accelerometerOptions.frequency)) {

            watchObj = {
                onSuccess: accelerometerSuccess,
                onError: accelerometerError,
                interval: accelerometerOptions.frequency
            };

            _watches[watchId] = watchObj;

            _watches[watchId].intervalId = setInterval(function () {
                self.getCurrentAcceleration(_watches[watchId].onSuccess, _watches[watchId].onError);
            }, accelerometerOptions.frequency);

        }
        else {
            if (typeof accelerometerError === "function") {
                setTimeout(function () {
                    accelerometerError();
                }, 1);
            }
        }

        return watchId;
    },

    clearWatch: function (watchId) {
        clearInterval(_watches[watchId].intervalId);
    }
};

event.on("AccelerometerInfoChangedEvent", function (accelerometerInfo) {
    _accelerometerInfo.x = accelerometerInfo.accelerationIncludingGravity.x / 9.8;
    _accelerometerInfo.y = accelerometerInfo.accelerationIncludingGravity.y / 9.8;
    _accelerometerInfo.z = accelerometerInfo.accelerationIncludingGravity.z / 9.8;
    _accelerometerInfo.timestamp = (new Date()).getTime();
});
