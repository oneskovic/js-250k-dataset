var Promise = Em.RSVP.Promise;


EG.EmberGraphAdapter = EG.Adapter.extend({

	
	serializer: Em.computed(function() {
		return this.get('container').lookup('serializer:ember_graph');
	}).property().readOnly(),

	createRecord: function(record) {
		var _this = this;
		var typeKey = record.get('typeKey');
		var serializerOptions = { requestType: 'createRecord', recordType: typeKey };
		var json = this.serialize(record, serializerOptions);

		return this.serverCreateRecord(typeKey, json).then(function(payload) {
			return _this.deserialize(payload, serializerOptions);
		});
	},

	findRecord: function(typeKey, id) {
		var _this = this;
		var serializerOptions = { requestType: 'findRecord', recordType: typeKey };

		return this.serverFindRecord(typeKey, id).then(function(payload) {
			return _this.deserialize(payload, serializerOptions);
		});
	},

	findMany: function(typeKey, ids) {
		var _this = this;
		var serializerOptions = { requestType: 'findMany', recordType: typeKey };

		return this.serverFindMany(typeKey, ids).then(function(payload) {
			return _this.deserialize(payload, serializerOptions);
		});
	},

	findAll: function(typeKey) {
		var _this = this;
		var serializerOptions = { requestType: 'findAll', recordType: typeKey };

		return this.serverFindAll(typeKey).then(function(payload) {
			return _this.deserialize(payload, serializerOptions);
		});
	},

	findQuery: function() {
		return Promise.reject('LocalStorageAdapter doesn\'t implement `findQuery` by default.');
	},

	updateRecord: function(record) {
		var _this = this;
		var typeKey = record.get('typeKey');
		var serializerOptions = { requestType: 'updateRecord', recordType: typeKey };
		var changes = this.serialize(record, serializerOptions);

		return this.serverUpdateRecord(typeKey, record.get('id'), changes).then(function(payload) {
			return _this.deserialize(payload, serializerOptions);
		});
	},

	deleteRecord: function(record) {
		var _this = this;
		var typeKey = record.get('typeKey');
		var serializerOptions = { requestType: 'deleteRecord', recordType: typeKey };

		return this.serverDeleteRecord(typeKey, record.get('id')).then(function(payload) {
			return _this.deserialize(payload, serializerOptions);
		});
	},

	serialize: function(record, options) {
		return this.get('serializer').serialize(record, options);
	},

	deserialize: function(payload, options) {
		return this.get('serializer').deserialize(payload, options);
	}

});