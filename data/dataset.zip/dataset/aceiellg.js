define(function(require, exports, module) {

    require("pilot/index");
    require("pilot/fixoldbrowsers");
    var catalog = require("pilot/plugin_manager").catalog;
    catalog.registerPlugins([ "pilot/index" ]);

    var Dom = require("pilot/dom");
    var Event = require("pilot/event");

    var Editor = require("ace/editor").Editor;
    var EditSession = require("ace/edit_session").EditSession;
    var UndoManager = require("ace/undomanager").UndoManager;
    var Renderer = require("ace/virtual_renderer").VirtualRenderer;

    exports.edit = function(el) {
        if (typeof(el) == "string") {
            el = document.getElementById(el);
        }

        var doc = new EditSession(Dom.getInnerText(el));
        doc.setUndoManager(new UndoManager());
        el.innerHTML = '';

        var editor = new Editor(new Renderer(el, require("ace/theme/textmate")));
        editor.setSession(doc);

        var env = require("pilot/environment").create();
        catalog.startupPlugins({ env: env }).then(function() {
            env.document = doc;
            env.editor = editor;
            editor.resize();
            Event.addListener(window, "resize", function() {
                editor.resize();
            });
            el.env = env;
        });
        // Store env on editor such that it can be accessed later on from
        // the returned object.
        editor.env = env;
        return editor;
    };
});