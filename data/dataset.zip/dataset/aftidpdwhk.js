define(["cdf/Dashboard.Clean", "cdf/components/ExecutePrptComponent", "cdf/lib/jquery"],
  function(Dashboard, ExecutePrptComponent, $) {

  /**
   * ## The Execute Prpt Component
   */
  describe("The Execute Prpt Component #", function() {

    var myDashboard = new Dashboard();

    myDashboard.init();

    var executeTopTenCustomers = new ExecutePrptComponent({
      name: "executeTopTenCustomers",
      type: "executePrpt",
      path: "/public/Steel Wheels/Widget Library/Report Snippets/Product Sales.prpt",
      listeners:["productLine", "territory"],
      parameters: [["productLine", '""'], ["territory", '""']],
      htmlObject: "sampleObject",
      paginate: false,
      showParameters: true,
      label: "Execute Prpt",
      executeAtStart: true,
      preChange: function() {return true;},
      postChange: function() {return true;},
      tooltip: "Click to generate report"
    });

    myDashboard.addComponent(executeTopTenCustomers);

    /**
     * ## The Execute Prpt Component # Update Called
     */
    it("Update Called", function(done) {
      spyOn(executeTopTenCustomers, 'update').and.callThrough();
      spyOn(executeTopTenCustomers, 'placeholder').and.returnValue($("<div/>"));
      myDashboard.update(executeTopTenCustomers);
      setTimeout(function() {
        expect(executeTopTenCustomers.update).toHaveBeenCalled();
        done();
      }, 100);
    });
  });
});
