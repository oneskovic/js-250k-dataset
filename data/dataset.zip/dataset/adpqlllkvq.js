(function() {

commands.addUserCommand(["gr"],
    "Google Results",
    function (args) {
        var doc = window.content.document;
        if(args >= 1) {
            var results = doc.querySelectorAll("div > ol > li > div > h3 > a");
            if(args <= results.length) {
                results[args - 1].click(); 
            }
            else {
                console.error("Not that many results");
            }
        }
        else {
            (doc.querySelector("div > p > a.spell") || doc.querySelector("div > button")).click();
        }
    });
})();
