var _self,
    utils = require('ripple/utils'),
    exception = require('ripple/exception'),
    event = require('ripple/event'),
    Rotation = require('ripple/platform/w3c/1.0/Rotation'),
    Acceleration = require('ripple/platform/w3c/1.0/Acceleration'),
    _motion = {
        acceleration: new Acceleration(0, 0, 0),
        accelerationIncludingGravity: new Acceleration(0, 0, -9.81),
        rotationRate: new Rotation(0, 0, 0),
        orientation: new Rotation(0, 0, 0),
        interval: 60000,
        timestamp: new Date().getTime()
    };

function _validateAccelerometerInfo(x, y, z) {
    return !(isNaN(x) || isNaN(y) || isNaN(z));
}

_self = {
    getInfo: function () {
        return utils.copy(_motion);
    },

    setInfo: function (e) {
        var triggerDeviceMotion = false,
            triggerDeviceOrientation = false;

        if (e.x !== undefined && e.y !== undefined && e.z !== undefined) {
            _motion = {
                acceleration: new Acceleration(e.x, e.y, e.z),
                accelerationIncludingGravity: new Acceleration(e.x, e.y, e.z),
                rotationRate: new Rotation(0, 0, 0),
                orientation: new Rotation(e.alpha, e.beta, e.gamma),
                timestamp: new Date().getTime()
            };
            triggerDeviceMotion = true;
            triggerDeviceOrientation = true;
        }
        else {
            _motion = {
                acceleration: new Acceleration(0, 0, 0),
                accelerationIncludingGravity: new Acceleration(0, 0, -9.81),
                rotationRate: new Rotation(0, 0, 0),
                orientation: new Rotation(0, 0, 0),
                timestamp: new Date().getTime()
            };
        }

        if (triggerDeviceMotion) {
            event.trigger("DeviceMotionEvent", [_motion]);
        }

        if (triggerDeviceOrientation) {
            event.trigger("DeviceOrientationEvent", [_motion]);
        }

        event.trigger("AccelerometerInfoChangedEvent", [_motion]);
    },

    triggerEvent: function() {
        event.trigger("DeviceMotionEvent", [_motion]);
        event.trigger("DeviceOrientationEvent", [_motion]);
        event.trigger("AccelerometerInfoChangedEvent", [_motion]);
    },

    shake: function (shakeXtimes) {
        var id,
            count = 1,
            stopCount = shakeXtimes || 17,
            oldX = _motion.accelerationIncludingGravity.x;

        id = setInterval(function () {
            var freq = 1,
                amp = 30,
                value = Math.round(amp * Math.sin(freq * count * (180 / Math.PI)) * 100) / 100;

            if (count > stopCount) {
                _motion.acceleration.x = oldX;
                _motion.accelerationIncludingGravity.x = oldX;
                event.trigger("AccelerometerInfoChangedEvent", [_motion]);
                clearInterval(id);
                return;
            }

            _motion.acceleration.x = value;
            _motion.accelerationIncludingGravity.x = value;

            event.trigger("AccelerometerInfoChangedEvent", [_motion]);

            count++;

        }, 80);
    },

    init: function () {
        event.on("DeviceMotionEventAddedEvent", function () {
            _self.triggerEvent();
        });
        event.on("DeviceOrientationEventAddedEvent", function () {
            _self.triggerEvent();
        });
    }
};

module.exports = _self;
