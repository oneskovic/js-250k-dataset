"use strict";

var ObjectManager   = require('../../object/manager'),
    util            = require('util');


function RowAbstract(config) {
    ObjectManager.call(this, config);

    this.data = {};
    this.modified = {}
    this.new = true;
};

util.inherits(RowAbstract, ObjectManager);


RowAbstract.prototype.setData = function (data) {
    var length = Object.keys(this.data).length;

    if (length > 0 && !this.new) {
        for(var index in data) {
            this.modified[index] = data[index];
            this.data[index] = data[index];
        }
    } else {
        if(length == 0) {
            this.data = data || {};
        } else {
            for(var index in data) {
                this.data[index] = data[index];
            }
        }
    }

    return this;
};

/**
 * This method will return only the data from the Row object
 *
 * @method getData
 * @returns {Promise} The data of the Row object
 */
RowAbstract.prototype.getData = function () {
        return this.data;
};

/**
 * This method will check if the row object is new or not
 *
 * @method isNew
 * @returns {boolean} True if new, False if exists
 */
RowAbstract.prototype.isNew = function () {
    return this.new;
};

/**
 * This function will clone the object and return a new RowAbstract object.
 *
 * @method clone
 * @returns {RowAbstract} The newly created RowAbstract
 */
RowAbstract.prototype.clone = function() {
    return new RowAbstract({
        identifier: this.getIdentifier()
    });
}

module.exports = RowAbstract;