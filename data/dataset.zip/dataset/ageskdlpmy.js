ES5Harness.registerTest({

    id: "15.4.4.21-9-b-21",

    path: "TestCases/chapter15/15.4/15.4.4/15.4.4.21/15.4.4.21-9-b-21.js",

    description: "Array.prototype.reduce - deleting own property causes deleted index property not to be visited on an Array-like object",

    test: function testcase() {

        var accessed = false;
        var testResult = true;

        function callbackfn(accum, val, idx, obj) {
            accessed = true;
            if (idx === 1) {
                testResult = false;
            }
        }

        var obj = { 5: 10, length: 10 };

        Object.defineProperty(obj, "1", {
            get: function () {
                return 6.99;
            },
            configurable: true
        });

        Object.defineProperty(obj, "0", {
            get: function () {
                delete obj[1];
                return 0;
            },
            configurable: true
        });

        Array.prototype.reduce.call(obj, callbackfn, "initialValue");
        return testResult && accessed;
    },

    precondition: function prereq() {
        return fnExists(Array.prototype.reduce) && fnExists(Object.defineProperty) && fnSupportsArrayIndexGettersOnObjects();
    }

});
