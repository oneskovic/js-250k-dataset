define(['jquery', 'oae.core'], function($, oae) {

    return function(uid) {

        // The widget container
        var $rootel = $('#' + uid);

        /**
         * Render the metadata for the current folder
         *
         * @param  {Folder}    folderProfile    Folder for which the metadata should be rendered
         */
        var renderMetadata = function(folderProfile) {
            oae.api.util.template().render($('#aboutfolder-template', $rootel), {
                'folderProfile': folderProfile,
                'displayOptions': {
                     'linkTarget': '_blank'
                }
            }, $('#aboutfolder-container', $rootel));
        };

        /**
         * Initialize the aboutfolder modal dialog
         */
        var setUpAboutFolder = function() {
            $(document).on('click', '.oae-trigger-aboutfolder', function(ev, data) {
                // Request the context profile information
                $(document).trigger('oae.context.get', 'aboutfolder');
            });

            // Receive the context's profile information and set up the aboutfolder modal
            $(document).on('oae.context.send.aboutfolder', function(ev, folderProfile) {
                // Show the aboutfolder modal
                $('#aboutfolder-modal', $rootel).modal();
                // Render the metadata for the current folder
                renderMetadata(folderProfile);
            });
        };

        setUpAboutFolder();

    };
});
