module.exports = function(app, config) {

	var _ = require('underscore');
	var agentApiClient = require('./services/agent-api-client').create(config);
	var deployLifecycleClient = require('./services/deploy-lifecycle-client').create(config);

	app.get("/agents/list", app.ensureLoggedIn, function(req, res) {
		var agentsResp = [];

		config.agents.forEach(function(agent) {
			agentsResp.push({
				name: agent.name,
				group: agent.group,
				dead: agent.dead,
				version: agent.version,
				configVersion: agent.configVersion,
				loadBalancerState: agent.loadBalancerState
			});
		});

		agentsResp = _.sortBy(agentsResp);
		res.json(agentsResp);
	});

	function handleNewLoadBalancerState(agent, newState) {
		var prevState = agent.loadBalancerState;
		agent.loadBalancerState = newState;

		if (!prevState || !newState) {
			return;
		}

		var stateDiff = newState.enabled !== prevState.enabled;
		var connDiff = Math.abs(newState.connectionCount - prevState.connectionCount);
		if (stateDiff || connDiff > 0) {
			clientSockets.sockets.volatile.emit('agent:event', {
				eventName: 'loadBalancerStateChanged',
				agentName: agent.name,
				state: newState
			});
		}
	}

	app.post("/agent/heartbeat", function(req, res) {

		var agent = config.getAgent(req.body.name);
		if (!agent) {
			agent = { name: req.body.name };
			config.agents.push(agent);
		}

		agent.url = req.body.url;
		agent.lastHeartBeat = new Date();
		agent.apiKey = req.body.apiKey;
		agent.dead = false;
		agent.version = req.body.version;
		agent.configVersion = req.body.configVersion;
		agent.group = req.body.group;

		handleNewLoadBalancerState(agent, req.body.loadBalancerState);

		res.json('ok');
	});

	app.post("/agent/event", function(req, res) {
		clientSockets.sockets.volatile.emit('agent:event', req.body);
		app.vent.emit('agentEvent:' + req.body.eventName, req.body);
		deployLifecycleClient.send(req.body.eventName, req.body, req.body.correlationId);
		res.json("ok");
	});

	app.post("/agent/log", function(req, res) {
		clientSockets.sockets.volatile.emit('agent:log', req.body);
		res.json("ok");
	});

	app.post("/agent/action", app.ensureLoggedIn, function(req, res) {
		agentApiClient.sendCommand(req.body.agentName, '/action', req.body, req.user);
		res.json('ok');
	});

	// query params: agentName, url
	app.get("/agent/query", app.ensureLoggedIn, function(req, res) {
		agentApiClient.get(req.query.agentName, req.query.url, function(data) {
			res.json(data);
		});
	});
};