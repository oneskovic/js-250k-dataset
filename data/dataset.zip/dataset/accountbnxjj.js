var base = require('cassandra-orm/lib/orm/base');


var Account = function(attributes) {
  base.DBBase.call(this, Account, attributes);
};

/**
 * Add properties that help map to cassandra
 * complex types
 */
Account.meta = {
  name: 'Account',
  cname: 'account',
  columnFamily: 'accounts',
  prefix: 'ac',
  dataPrefix: null,
  parents: []
};

/**
 * Fields on the Account
 */
Account.fields = {
  'metadata': {'default_value': {}},
  'status': {'default_value': 'active'},

  // account object limits
  'limits': {'default_value': { 'service': 200, 'configuration_value': 1000 }}
};

Account.operationalVersion = 4;
base.inheritBase(Account, __filename);

exports.Account = Account;
