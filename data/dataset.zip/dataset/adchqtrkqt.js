ES5Harness.registerTest({

    id: "15.4.4.16-5-12",

    path: "TestCases/chapter15/15.4/15.4.4/15.4.4.16/15.4.4.16-5-12.js",

    description: "Array.prototype.every - Boolean Object can be used as thisArg",

    test: function testcase() {

        var accessed = false;
        var objBoolean = new Boolean();

        function callbackfn(val, idx, obj) {
            accessed = true;
            return this === objBoolean;
        }

       

        return [11].every(callbackfn, objBoolean) && accessed;
    },

    precondition: function prereq() {
        return fnExists(Array.prototype.every);
    }

});
