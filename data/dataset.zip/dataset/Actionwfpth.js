goog.provide('tart.mvc.Action');




tart.mvc.Action = function(params, layout, view, controller) {
    this.params = params;
    this.view = view;
    this.layout_ = layout;
    this.controller = controller;
};


/**
 *
 * @param {tart.mvc.LayoutTemplate} layout Layout.
 */
tart.mvc.Action.prototype.setLayout = function(layout) {
    this.layout_ = layout;
};


/** @nosideeffects */
tart.mvc.Action.prototype.params;


/** @nosideeffects */
tart.mvc.Action.prototype.layout;


/** @nosideeffects */
tart.mvc.Action.prototype.view;


/**
 * @return {tart.mvc.LayoutTemplate} The layout template (whether custom or default) that belongs to the action.
 */
tart.mvc.Action.prototype.getLayout = function() {
    return this.layout_;
};


/**
 * Deconstructor method of this action. Developers should override this property in an action function like;
 *
 * this.deconstructor = function() {}
 *
 * and should deallocate the memory they have used in the action. This is also helpful for resolving issues that arise
 * because of tartMVC's statefullness; such as removed but dangling DOM nodes, etc.
 */
tart.mvc.Action.prototype.deconstructor = null;


/**
 * @return {tart.mvc.ViewTemplate} The view script that belongs to the action.
 */
tart.mvc.Action.prototype.getViewScript = function() {
    if (!this.viewScript_)
        throw new tart.Err('No view script set for the action', 'tartMVC Action Exception');

    return this.viewScript_;
};


/**
 * Sets the action's view script.
 * @param {tart.mvc.ViewTemplate} viewScript view script.
 */
tart.mvc.Action.prototype.setViewScript = function(viewScript) {
    this.viewScript_ = viewScript;
};
