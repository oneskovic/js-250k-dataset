Ext.define('Ext.device.notification.Abstract', {
    
    show: function(config) {
        if (!config.message) {
            throw('[Ext.device.Notification#show] You passed no message');
        }

        if (!config.buttons) {
            config.buttons = "OK";
        }

        if (!Ext.isArray(config.buttons)) {
            config.buttons = [config.buttons];
        }

        if (!config.scope) {
            config.scope = this;
        }

        return config;
    },

    /**
     * Vibrates the device.
     */
    vibrate: Ext.emptyFn
});
