Ext.define('Ext.ActionSheet', {
    extend: 'Ext.Sheet',
    alias : 'widget.actionsheet',
    requires: ['Ext.Button'],

    config: {
        
        baseCls: Ext.baseCSSPrefix + 'sheet-action',

        
        left: 0,

        
        right: 0,

        
        bottom: 0,

        // @hide
        centered: false,

        
        height: 'auto',

        
        defaultType: 'button'
    },

    platformConfig: [{
        theme: ['Windows'],
        top: 0,
        bottom: null
    }, {
        theme: ['Blackberry'],
        top: 0,
        left: null,
        enter: 'right',
        exit: 'right',
        hideOnMaskTap: true,
        baseCls: 'bb-crosscut',
        scrollable: true,
        layout: {
            type: 'vbox',
            pack: 'middle'
        },
        defaultType: 'button',
        showAnimation: {
            easing: 'linear',
            preserveEndState: true,
            to: {
                width: 250
            }
        },
        hideAnimation: {
            easing: 'linear',
            preserveEndState: true,
            to: {
                width: 68
            }
        }
    }]
});
